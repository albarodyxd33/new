enum Test {
    Hoo = 'hoo'
}

const spiderman = (person: String) => {
    return 'Hello, ' + person;
}

let user = 1;
console.log(spiderman(user));
