import json
from os import getenv, path
from pprint import pprint
import sys


a=1;b=2
c=a+b
BROKEN_VAR=BROKEN_VAR
print(c)
