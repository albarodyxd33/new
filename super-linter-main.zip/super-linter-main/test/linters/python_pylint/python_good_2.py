"""Test Python file for Pylint."""

import pytest

print(pytest)
