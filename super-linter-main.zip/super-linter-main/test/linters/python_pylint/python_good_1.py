"""Test Python file for Pylint."""

A = 1
B = 2
C = A + B
print(C)
