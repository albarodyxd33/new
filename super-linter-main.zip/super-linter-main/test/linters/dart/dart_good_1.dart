class Point {
  int x, y;
  Point(this.x, this.y);
}
