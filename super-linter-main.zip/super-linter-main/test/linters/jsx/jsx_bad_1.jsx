import React from 'react';

var Hello = <a target='_blank' href="https://example.com/"></a>
