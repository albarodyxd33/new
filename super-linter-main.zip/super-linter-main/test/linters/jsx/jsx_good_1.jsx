import React from 'react';

const element = <h1>Hello, world!</h1>;
console.log(element)
