function hello() {
  echo "Hello, world!"
}
