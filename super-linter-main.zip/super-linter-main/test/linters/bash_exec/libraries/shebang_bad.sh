#!/usr/bin/env bash
function hello() {
  echo "Hello, world!"
}
