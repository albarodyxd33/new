 #!/usr/bin/env whatever
function hello() {
  echo "Hello, world!"
}
