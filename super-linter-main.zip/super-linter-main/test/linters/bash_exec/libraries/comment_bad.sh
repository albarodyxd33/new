# A comment is not a shebang
function hello() {
  echo "Hello, world!"
}
