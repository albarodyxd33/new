var teamId = "teamId"

function checkTeamIDVariable(teamId) {
  if (typeof teamId != "undefined") {
    console.log(teamId)
  }
}

checkTeamIDVariable(teamId)
