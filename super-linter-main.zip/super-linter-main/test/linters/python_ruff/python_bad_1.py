import pandas
import numpy as np

c = 1 + 2
print(c)
