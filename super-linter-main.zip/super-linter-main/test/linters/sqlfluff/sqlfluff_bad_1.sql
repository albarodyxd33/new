SELECT
    a
FROM foo AS zoo;
